﻿using System;

namespace ProjectOne.Domain
{
    public class Class1
    {
    }
}
