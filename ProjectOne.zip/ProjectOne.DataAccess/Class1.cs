﻿using System;

namespace ProjectOne.DataAccess
{
    public class Class1
    {
    }
}
